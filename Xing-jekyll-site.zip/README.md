# Jin Xing — Personal Site (GitHub Pages + Jekyll Minimal Mistakes)

**How to deploy**
1. Rename repo to `YOUR_GITHUB_USERNAME.github.io` (public).
2. Push these files to the repo root on the `main` branch.
3. In **Settings → Pages**, set **Source**: Deploy from branch → `main` → `/ (root)`.
4. Your site will be live at `https://YOUR_GITHUB_USERNAME.github.io`.
5. Edit `_config.yml` to replace `YOUR_GITHUB_USERNAME` and your social links.