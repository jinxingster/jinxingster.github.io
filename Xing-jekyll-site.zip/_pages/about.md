---
layout: single
title: "About"
permalink: /about/
---

I’m **Jin Xing**, an Advanced Analytics Manager at **TD Insurance** in Toronto, Canada. Previously, I was a Lecturer (Assistant Professor) in Geospatial Analysis at **Newcastle University**. I completed my PhD in Geography at **McGill University**.

### Research focus
Catastrophe modelling, GeoAI, smart cities/CyberGIS, and remote sensing (with a strong emphasis on SAR).

### Selected highlights
- PI/Co-I on funded projects spanning explainable GeoAI, smart cities, and logistics.
- 40+ peer‑reviewed papers across IJAEOG, TGRS, IJDE, Remote Sensing, etc.
- Regular reviewer for UK research councils and international journals.

For a full CV and publication list, see my Google Scholar profile linked in the header.