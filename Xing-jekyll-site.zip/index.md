---
layout: home
title: "Home"
author_profile: true
excerpt: "GeoAI • Catastrophe Modelling • Flood & Wildfire • ESG analytics"
---

Welcome! I'm **Jin Xing**, a GeoAI scientist focused on flood and wildfire risk modelling, remote sensing (SAR), and climate & ESG analytics.

This site hosts short notes, publications, and project highlights.